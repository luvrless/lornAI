﻿# lornAI for macOS
Run `./install.sh` in Terminal to install lornAI to ~/Applications and create a Desktop launcher.
Developed by Frail (https://lorn.lol)
